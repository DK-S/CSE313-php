CS 313 PHP Base Code
